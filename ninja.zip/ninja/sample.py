from __future__ iport division
from random import *

class o:
  def __init__(i,**d)    : i.add(**d)
  
the = o(SAMPLE = o(max=256))

def hundred(lst,n=100):
  if len(lst) < n:
    return hundred(lst + lst)
  inc  = int(len(lst)/n + 0.5)
  return sorted(lst)[0::inc]
  
class Sample:
  "Keep, at most, 'size' things."
  def __init__(i, init=[], size=None):
    i.max = size or the.SAMPLE.max
    i.n, i.all, i.ordered = 0, [], False
    map(i.__iadd__,init)
  def __iadd__(i,x):
    i.ordered = False
    i.n += 1
    now  = len(i.all)
    if now < i.max:
      i.all += [x]
    elif r() <= now/i.n:
      i.all[ int(r() * now) ]= x
    return i
